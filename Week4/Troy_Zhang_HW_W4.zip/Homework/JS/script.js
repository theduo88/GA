$(function() {
    console.log( "ready!" );




	$( ".readmore" ).click(function(event) {
	  $( "#show-this-on-click" ).slideDown( "slow", function() {
	  });
	  $( ".readless" ).show( "slow", function() {
	  });

	  $( ".readmore" ).hide();

	  event.preventDefault();
	});



	$( ".readless" ).click(function(event) {
	  $( "#show-this-on-click" ).slideUp( "slow", function() {
	  });
	  $( ".readless" ).hide( "slow", function() {
	  });
	  $( ".readmore" ).show( "slow", function() {
	  });
	  event.preventDefault();
	});



	$( ".learnmore" ).click(function(event) {
	  $( "#learnmoretext" ).slideDown( "slow", function() {
	  });

	  $( ".learnmore" ).hide();

	  event.preventDefault();
	});


});